package com.android.launcher3;

import android.view.MotionEvent;

public interface WorkspaceCallbacks {

    boolean onInterceptTouchEvent(MotionEvent event);
}
