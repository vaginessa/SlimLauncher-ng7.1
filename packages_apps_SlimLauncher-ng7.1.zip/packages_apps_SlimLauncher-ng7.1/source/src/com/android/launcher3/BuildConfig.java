package com.android.launcher3;

public class BuildConfig {

    public static final String APPLICATION_ID = "com.slim.slimlauncher";

}
